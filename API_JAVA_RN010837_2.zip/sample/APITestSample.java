//package securedbapitest;

import com.ksign.securedb.api.SDBCrypto;
import com.ksign.securedb.api.util.*;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.*;
import java.util.HashMap;
import java.util.Hashtable;

public class APITestSample {
	final int MAXCOUNT = 1;
	

    public static void main(String[] args) throws Exception {
    		APITestSample test = new APITestSample();
    		test.doAPITest(args);
    		test = null;
    }

    public void doAPITest(String[] args) throws Exception {
        
        try {   
        	BufferedReader inputInfo = new BufferedReader(new InputStreamReader(System.in));
        	System.out.println("***** Select Menu *****");
        	System.out.println(" 1. Use Config File ");
        	System.out.println(" 2. Not Use Config File");
        	System.out.println(" 3. File Encrypt/Decrypt");
        	System.out.println(" 4. File Encrypt/Decrypt(LINE)");
        	System.out.println(" 5. LOB TYPE Encrypt/Decrypt");
        	System.out.println("***********************");
        	System.out.print("[INPUT NUMBER >> ");
        	char choice = inputInfo.readLine().charAt(0);
        	
        	String ServerIP = "";
        	int ServerPort = 0;
        	String schema = "";
        	String table = "";
        	String column = "";
        	String DomainName = "";
        	String path = "";
    	
        	String pData = "";
        	String encData = null;
        	String decData = null;

		String charSet = "";
     
        	System.out.println("_____________________________ FULL ENC SAMPLE TEST ______________________________");
        	if(choice == '1') {
        		System.out.print("\n[1. INPUT SCHEMA $] ");
        		schema = inputInfo.readLine();
        		System.out.print("\n[2. INPUT TABLE NAME $] ");
        		table = inputInfo.readLine();
        		System.out.print("\n[3. INPUT COLUMN NAME $] ");
        		column = inputInfo.readLine();
        		System.out.print("\n[4. INPUT PLAIN TEXT $] ");
        		pData = inputInfo.readLine();
                long encstarttime = System.currentTimeMillis();
              
        		for(int i=0;i<MAXCOUNT;i++) {
        			encData = SDBCrypto.encryptCEV(schema, table, column, pData);
        			if(encData == null) {
        				System.out.println("Fail to Encrypt Data.........");
        				return;
        			}
//        			System.out.println("Success Encrypt Data ["+pData+"]=["+encData+"]");
        		}
           		long encendtime = System.currentTimeMillis();
        	    System.out.println("ENC Time : " + (encendtime - encstarttime)*0.001 + "sec");
        	    
        	    long decstarttime = System.currentTimeMillis();
        		for(int i=0;i<MAXCOUNT;i++) {
        			decData = SDBCrypto.decryptCEV(schema, table, column, encData);
        			if(decData == null) {
        				System.out.println("Fail to Decrypt Data.........");
        				return;
        			}
//        			System.out.println("Success Decrypt Data ["+encData+"]=["+decData+"]");
        		}
        		long decendtime = System.currentTimeMillis();
        	    System.out.println("Dec Time : " + (decendtime - decstarttime)*0.001 + "sec");
        	    
        	    System.out.println("Success Decrypt Data ["+encData+"]=["+decData+"]");
        	    System.out.println("Success Encrypt Data ["+pData+"]=["+encData+"]");
        	    

        	}
        	else if(choice == '2') {
        		SDBCrypto crypto = null;
        		
        		/* Input Information */
        		System.out.println("==================== INPUT INFORMATION =========================");
        		System.out.print("[1. INPUT DOMAIN_NAME $] ");
        		DomainName = inputInfo.readLine();
        		System.out.print("\n[2. INPUT SERVER IP ADDRESS $] ");
        		ServerIP = inputInfo.readLine();
        		System.out.print("\n[3. INPUT SERVER PORT $] ");
        		ServerPort = Integer.parseInt(inputInfo.readLine());
        		System.out.print("\n[4. INPUT SCHEMA $] ");
        		schema = inputInfo.readLine();
        		System.out.print("\n[5. INPUT TABLE NAME $] ");
        		table = inputInfo.readLine();
        		System.out.print("\n[6. INPUT COLUMN NAME $] ");
        		column = inputInfo.readLine();
        		System.out.print("\n[7. INPUT PLAIN TEXT $] ");
        		pData = inputInfo.readLine();
        		        		       		
        		long instancestart = System.currentTimeMillis();
        		crypto = SDBCrypto.getInstanceDomain(DomainName, ServerIP, ServerPort);
        		if(crypto == null) {
        			System.out.println("Fail to Get SDBAPI Infomation... (Fail getInstance())");
        			return;
        		}
        		long instanceend = System.currentTimeMillis();
        	    System.out.println("GetIntance Time : " + (instanceend - instancestart)*0.001 + "sec");
   
        		
        		{
        		long encstarttime = System.currentTimeMillis();
        		for(int i=0;i<MAXCOUNT;i++) {
        			encData = crypto.encryptDP(schema, table, column, pData, null,0);
        			if(encData == null) {
        				System.out.println("Fail to Encrypt Data.........");
        				return;
        			}
        			System.out.println("Success Encrypt Data ["+pData+"]=["+encData+"]");
        		}
           		long encendtime = System.currentTimeMillis();
        	    System.out.println("ENC Time : " + (encendtime - encstarttime)*0.001 + "sec");
        	    
        	    long decstarttime = System.currentTimeMillis();
        		for(int i=0;i<MAXCOUNT;i++) {
        			decData = crypto.decryptDP(schema, table, column, encData,null,0);
        			if(decData == null) {
        				System.out.println("Fail to Decrypt Data.........");
        				return;
        			}
        			System.out.println("Success Decrypt Data ["+encData+"]=["+decData+"]");
        		}
				long decendtime = System.currentTimeMillis();
        	    System.out.println("Dec Time : " + (decendtime - decstarttime)*0.001 + "sec");
        	    System.out.println("Success Decrypt Data ["+encData+"]=["+decData+"]");
        	    System.out.println("Success Encrypt Data ["+pData+"]=["+encData+"]");
        		}        	    
        	}
       		else if(choice == '3') {
      		
        			SDBCrypto crypto = null;
        			boolean ret = false;
        			
            		/* Input Information */
       
            		System.out.println("==================== INPUT INFORMATION =========================");
            		System.out.print("[1. INPUT DOMAIN_NAME $] ");
            		DomainName = inputInfo.readLine();
            		System.out.print("\n[2. INPUT SERVER IP ADDRESS $] ");
            		ServerIP = inputInfo.readLine();
            		System.out.print("\n[3. INPUT SERVER PORT $] ");
            		ServerPort = Integer.parseInt(inputInfo.readLine());
            		System.out.print("\n[4. INPUT SCHEMA $] ");
            		schema = inputInfo.readLine();
            		System.out.print("\n[5. INPUT TABLE NAME $] ");
            		table = inputInfo.readLine();
            		System.out.print("\n[6. INPUT COLUMN NAME $] ");
            		column = inputInfo.readLine();
            		System.out.print("\n[7. INPUT FILE PATH $] ");
            		path = inputInfo.readLine();
            		
            		StringBuffer objName = new StringBuffer();
            		objName.append(schema);
            		objName.append(".");
             		objName.append(table);
            		objName.append(".");
             		objName.append(column);
            		
        			long instancestart = System.currentTimeMillis();
        			crypto = SDBCrypto.getInstanceDomain(DomainName, ServerIP, ServerPort);
        			if(crypto == null) {
        				System.out.println("Fail to Get SDBAPI Infomation... (Fail getInstance())");
        				return;
        			}
        			long instanceend = System.currentTimeMillis();
        			System.out.println("GetIntance Time : " + (instanceend - instancestart)*0.001 + "sec");
        		
        			long encstarttime = System.currentTimeMillis();
        			for(int i=0;i<MAXCOUNT;i++) {
        				ret = crypto.encryptFile(path, objName.toString(), false);
        				if(!ret) {
        					System.out.println("Fail to Encrypt File.........");
        					return;
        				}
        			}
        			long encendtime = System.currentTimeMillis();
        			System.out.println("ENC Time : " + (encendtime - encstarttime)*0.001 + "sec");

        			long decstarttime = System.currentTimeMillis();
        			for(int i=0;i<MAXCOUNT;i++) {
        				ret = crypto.decryptFile(path, objName.toString(), false);
        				if(!ret) {
        					System.out.println("Fail to Decrypt File.........");
        					return;
        				}
        			}
        			long decendtime = System.currentTimeMillis();
            	    System.out.println("Dec Time : " + (decendtime - decstarttime)*0.001 + "sec");
       		}
       		else if(choice == '4') {
          		
    			SDBCrypto crypto = null;
    			boolean ret = false;
    			
        		/* Input Information */

        		System.out.println("==================== INPUT INFORMATION =========================");
        		System.out.print("[1. INPUT DOMAIN_NAME $] ");
        		DomainName = inputInfo.readLine();
        		System.out.print("\n[2. INPUT SERVER IP ADDRESS $] ");
        		ServerIP = inputInfo.readLine();
        		System.out.print("\n[3. INPUT SERVER PORT $] ");
        		ServerPort = Integer.parseInt(inputInfo.readLine());
        		System.out.print("\n[4. INPUT SCHEMA $] ");
        		schema = inputInfo.readLine();
        		System.out.print("\n[5. INPUT TABLE NAME $] ");
        		table = inputInfo.readLine();
        		System.out.print("\n[6. INPUT COLUMN NAME $] ");
        		column = inputInfo.readLine();
        		System.out.print("\n[7. INPUT FILE PATH $] ");
        		path = inputInfo.readLine();
        		
        		StringBuffer objName = new StringBuffer();
        		objName.append(schema);
        		objName.append(".");
         		objName.append(table);
        		objName.append(".");
         		objName.append(column);
        		
    			long instancestart = System.currentTimeMillis();
    			crypto = SDBCrypto.getInstanceDomain(DomainName, ServerIP, ServerPort);
    			if(crypto == null) {
    				System.out.println("Fail to Get SDBAPI Infomation... (Fail getInstance())");
    				return;
    			}
    			long instanceend = System.currentTimeMillis();
    			System.out.println("GetIntance Time : " + (instanceend - instancestart)*0.001 + "sec");
    		

    			long encstarttime = System.currentTimeMillis();
    			for(int i=0;i<MAXCOUNT;i++) {

    				ret = crypto.encryptFileLine(path, objName.toString(), false);
				//ret = crypto.encryptFileLine(path, objName.toString(), "US-ASCII",false);
    				if(!ret) {
    					System.out.println("Fail to Encrypt File.........");
    					return;
    				}
    			}
    			long encendtime = System.currentTimeMillis();
    			System.out.println("ENC Time : " + (encendtime - encstarttime)*0.001 + "sec");

    			long decstarttime = System.currentTimeMillis();
    			for(int i=0;i<MAXCOUNT;i++) {

    				ret = crypto.decryptFileLine(path, objName.toString(), false);
				//ret = crypto.decryptFileLine(path, objName.toString(), "US-ASCII",false);
    				if(!ret) {
    					System.out.println("Fail to Decrypt File.........");
    					return;
    				}
    			}
    			long decendtime = System.currentTimeMillis();
    			System.out.println("Dec Time : " + (decendtime - decstarttime)*0.001 + "sec");
       		}
       		else if(choice == '5') {
          		
    			SDBCrypto crypto = null;
    			boolean ret = false;
    			String subString = "";
    			StringBuffer encbuff = new StringBuffer();
        		char[] plaintext = new char[4096];
        		int readlen = 0;
    			
        		/* Input Information */

        		System.out.println("==================== INPUT INFORMATION =========================");
        		System.out.print("[1. INPUT DOMAIN_NAME $] ");
        		DomainName = inputInfo.readLine();
        		System.out.print("\n[2. INPUT SERVER IP ADDRESS $] ");
        		ServerIP = inputInfo.readLine();
        		System.out.print("\n[3. INPUT SERVER PORT $] ");
        		ServerPort = Integer.parseInt(inputInfo.readLine());
        		System.out.print("\n[4. INPUT SCHEMA $] ");
        		schema = inputInfo.readLine();
        		System.out.print("\n[5. INPUT TABLE NAME $] ");
        		table = inputInfo.readLine();
        		System.out.print("\n[6. INPUT COLUMN NAME $] ");
        		column = inputInfo.readLine();
        		System.out.print("\n[7. INPUT FILE PATH $] ");
        		path = inputInfo.readLine();
        		
        		BufferedReader clobencbr = new BufferedReader(new FileReader(path));
        		BufferedWriter clobencbw=new BufferedWriter(new FileWriter(path+"_enc"));
        		
    			long instancestart = System.currentTimeMillis();
    			crypto = SDBCrypto.getInstanceDomain(DomainName, ServerIP, ServerPort);
    			if(crypto == null) {
    				System.out.println("Fail to Get SDBAPI Infomation... (Fail getInstance())");
    				return;
    			}
    			long instanceend = System.currentTimeMillis();
    			System.out.println("GetIntance Time : " + (instanceend - instancestart)*0.001 + "sec");
    		

    			long encstarttime = System.currentTimeMillis();
    			for(int i=0;i<MAXCOUNT;i++) {
    				while(true) {
            			if((readlen = clobencbr.read(plaintext, 0, 4096)) == -1){
            				break;
            			}
            			/* ENC FUNC */
            			String ptext = new String(plaintext,0,readlen);
            			encbuff.append(crypto.encryptLob(schema,table,column,ptext));
				//encbuff.append(crypto.encryptLob(schema,table,column,ptext,"US-ASCII"));
            		}
            		
    				clobencbw.write(encbuff.toString());
    				clobencbw.flush();
    			}
    			long encendtime = System.currentTimeMillis();
    			System.out.println("ENC Time : " + (encendtime - encstarttime)*0.001 + "sec");
    			
    			if(clobencbr != null) { clobencbr.close(); clobencbr = null; }
    			if(clobencbw != null) { clobencbw.close(); clobencbw = null; }
    			

          		BufferedReader clobdecbr = new BufferedReader(new FileReader(path+"_enc"));
        		BufferedWriter clobdecbw = new BufferedWriter(new FileWriter(path+"_dec"));
        		
        		int read = 0;
        		char[] dataLen = new char[8];
        		int len = 0;
         		StringBuffer dataLenBuff = new StringBuffer();
        		StringBuffer encDataBuff = new StringBuffer();
         		StringBuffer decDataBuff = new StringBuffer();
      			
    			long decstarttime = System.currentTimeMillis();
    			for(int i=0;i<MAXCOUNT;i++) {
            		while(true){
            			if((read = clobdecbr.read(dataLen,0,8)) == -1) {
            				break;
            			}
            			dataLenBuff.append(dataLen,0,read);
            			len = Integer.parseInt(dataLenBuff.toString());
            			
            			char[] databuff = new char[len];
            			
            			if((read = clobdecbr.read(databuff,0,len)) == -1) {
            				break;
            			}
            			
            			encDataBuff.append(databuff,0,read);

            			decDataBuff.append(crypto.decryptLob(schema,table,column, encDataBuff.toString(), false));
				//decDataBuff.append(crypto.decryptLob(schema,table,column, encDataBuff.toString(), false, "US-ASCII"));



            			
            			encDataBuff.delete(0, read);
            			dataLenBuff.delete(0, 8);
            		} 
            		clobdecbw.write(decDataBuff.toString());
			clobdecbw.flush();
    				
    			}
    			long decendtime = System.currentTimeMillis();
    			System.out.println("Dec Time : " + (decendtime - decstarttime)*0.001 + "sec");
    			if(clobdecbr != null) { clobdecbr.close(); clobdecbr = null; }
    			if(clobdecbw != null) { clobdecbw.close(); clobdecbw = null; }
       		}
        	else {
        		System.out.println("Wrong Menu Selection[ Input Number : "+choice+" ]");
        	}
        	System.out.println("_______________________________ END SAMPLE TEST ______________________________");
        }
        catch(Exception e){
        	System.out.println("System.out.println Test ---> Sample Source Print :: "+ e.getMessage());
        }
   }   
}
