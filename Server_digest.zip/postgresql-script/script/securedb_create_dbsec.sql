-- psql


-- �������� (id : dbsec , password : dbsec)
 CREATE ROLE DBSEC WITH SUPERUSER CREATEDB LOGIN PASSWORD 'DBSEC';


-- TABLESPACE location�� ����ڷκ��� �Է¹޴´�. (tablespace �� : SECUREDATA)
--CREATE TABLESPACE SECUREDATA owner &DBSEC location 'C:\Program Files\PostgreSQL\9.5\data\SECUREDATA';
--CREATE TABLESPACE SECUREDATA owner &DBSEC location '/var/lib/pgsql/9.5/data/SECUREDATA';
CREATE TABLESPACE SECUREDATA owner &DBSEC location '/var/lib/pgsql/9.5/data/SECUREDATA';


-- database ���� (database�� : SecureDB)
CREATE database SecureDB WITH OWNER = 'DBSEC'

commit;