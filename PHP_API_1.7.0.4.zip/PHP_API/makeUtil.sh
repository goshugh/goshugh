#-------------------------------------------------------------------------
#	����
#-------------------------------------------------------------------------
Usage()
{
	echo ""
	echo "__________________________________________________"
	echo ""
	echo "Command List)"
	echo "-whereismake"
	echo "-whereisgcc"
	echo "-whereiscc"
	echo "-getcflags <gccflag(default:cc): 1 == gcc,1 != cc > <bit(default:64): 64/32>"
	echo "-getldflags <gccflag(default:cc): 1 == gcc, 1!= cc>"
	echo "-getkernelbits"
	echo ""
	echo "__________________________________________________"
	echo ""
	exit 1
}

if [ $# -eq 0 ];
then
	Usage
fi

WHEREIS=`which whereis|awk '{print $1}'`
WHEREIS_OK=1
if [ "$WHEREIS" = "no" ];
then
	WHEREIS_OK=0
	WHEREIS=""
fi



#-------------------------------------------------------------------------
#	make ���� ���翩�� Ȯ��
#-------------------------------------------------------------------------
WhereIsMake()
{
	if [ -f /usr/local/bin/make ] ; then
		M=/usr/local/bin/make
	elif [ -f /usr/bin/gmake ] ; then
		M=/usr/bin/gmake
	else
		if [ $WHEREIS_OK -eq 1 ];
		then
			M=`$WHEREIS make | /usr/bin/awk '{ print $2 }'`		
		fi
	fi

	if [ ! "$M" ]
	then
		echo "There is no make"
		exit 1
	fi

	echo $M
	exit 0
}



#-------------------------------------------------------------------------
#	C Compiler ���翩�� Ȯ��
#-------------------------------------------------------------------------

WhereIsCC()
{
	CCOMPILER=$1

	CC=`which $CCOMPILER |/usr/bin/awk '{print $1}'`
	if [ "$CC" = "no" ]
	then
		CC=""
	elif [ "$CC" = "which:" ]
	then
		CC=""
	fi

	if [ ! "$CC" ];
	then
		if [ $WHEREIS_OK -eq 1 ];
		then
			CC=`$WHEREIS $CCOMPILER | /usr/bin/awk '{ print $2 }'`	
			if [ ! "$CC" ];
			then
				echo "There is no "$CCOMPILER" Compiler"
				exit 1
			fi
		else
			echo "There is no "$CCOMPILER" Compiler"
			exit 1
		fi
	fi
	echo $CC
	exit 0
}

#-------------------------------------------------------------------------
#	OS�� BITŸ�� Ȯ���ϴ� ���
#	SunOS	: isainfo -kv | /usr/bin/awk '{print $1}'
#	AIX	: bootinfo -y ( hardware root ���� �ʿ� )
#		  bootinfo -k ( kernel root ���� �ʿ� )
#		  �Ǵ� prfconf -K ( root ���� �ʿ� )
#	HP-UX	: getconf KERNEL_BITS
#	Linux	: file /bin/ls | /usr/bin/awk '{ print $3 }'
#-------------------------------------------------------------------------

#-------------------------------------------------------------------------
#	OS���� �� ���� Ȯ��
#-------------------------------------------------------------------------

# OS_TYPE	: os���� ( SunOS, HP-UX, Linux, AIX �� )
# OS_VERSION	: OS ���� ( uname -r ���ɾ� Solaris, HPUX, Linux ���� Ȯ�� )

OS_TYPE=`uname`
OS_VERSION=`uname -r`

#-------------------------------------------------------------------------
#	OS���� �� ���� Ȯ��
#-------------------------------------------------------------------------

GetKernelBits()
{
	KERNEL_BITS="64"
	case $OS_TYPE 
	in
	SunOS)
		KERNEL_BITS=`isainfo -kv | /usr/bin/awk '{print $1}'`
		if [ "$KERNEL_BITS" = "32-bit" ];
		then
			KERNEL_BITS="32"
		else
			KERNEL_BITS="64"
		fi
	;;
	AIX)
		KERNEL_BITS=`bootinfo -k`
		if [ $? -ne 0 ];
		then
			KERNEL_BITS="64"
		fi			
	;;
	HP-UX)
		KERNEL_BITS=`getconf KERNEL_BITS`
	;;
	Linux)
		KERNEL_BITS=`file /bin/ls | /usr/bin/awk '{ print $3 }'`
		if [ "$KERNEL_BITS" = "32-bit" ];
		then
			KERNEL_BITS="32"
		else
			KERNEL_BITS="64"
		fi
	;;
	esac

	echo $KERNEL_BITS
	exit 0
}


#-------------------------------------------------------------------------
#	CFLAGS�� ����
#-------------------------------------------------------------------------

GetCflags()
{
	# IS_GCC	: �����Ϸ����� --> 1 �̸� gcc , 0 �̸� cc
	# BIT		: bit 64/32bit
	# OPTMIZATION	: ����ȭ ���
	

	IS_GCC=0
	BIT=64
	OPTMIZATION=" -O3 "
	#OPTMIZATION=" -O0 "
	PRE_DEFINE=" -D_PHP7_ "	
	#PRE_DEFINE=" -D_KSIGN_DEBUG "
	#PRE_DEFINE=${PRE_DEFINE}" -D_ELAPSED_TIME "
	#PRE_DEFINE=${PRE_DEFINE}" -D_DECRYPT "
	#PRE_DEFINE=${PRE_DEFINE}" -D_ENCRYPT "
	#PRE_DEFINE=${PRE_DEFINE}" -D_HASHCHECK "

	OPTION=""

	if [ $1 -eq 1 ];
	then
		IS_GCC=1
	fi

	if [ $2 -eq 32 ];
	then
		BIT=32
	fi

	case $OS_TYPE 
	in
	#	SunOS	--------------------------------------------------------------
	# if (intel, 64bit, gcc) {
	#   PRE_DEFINE=" -D_SUNOS -D__LITTLE_ENDIAN -DLITTLE_ENDIAN "
	#   OPTION=${OPTION} " -m64 "
	# }
	SunOS)
		PRE_DEFINE=${PRE_DEFINE}" -DCOMPILE_DL_SDBAPIEXPORT -D_SUNOS -D__SDB_BIG_ENDIAN "

		if [ $IS_GCC -eq 1 ];
		then
			OPTION=" -m$BIT -fPIC "			
		else
			OPTMIZATION=" -O "
			OPTION=" -KPIC -xc99=all "

			if [ "$BIT" = "64" ];
			then
				OPTION=${OPTION}" -xarch=v9 "
			else
				OPTION=${OPTION}" -xarch=v8plusa "
			fi
		fi
		

		# ���� Ȯ�� 5.7 �������� inet_ntop�� ���� ������ ���� ó��	090329
		if [ "$OS_VERSION" != "5.7" ];
		then
			PRE_DEFINE=${PRE_DEFINE}" -DHAVE_INET_NTOP "
		fi
	;;
	#	AIX	--------------------------------------------------------------
	AIX)
		PRE_DEFINE=${PRE_DEFINE}" -DCOMPILE_DL_SDBAPIEXPORT -D_AIX -D__SDB_BIG_ENDIAN "

		if [ $IS_GCC -eq 1 ];
		then
			OPTION=" -maix$BIT -fPIC "
		else
			OPTION=" -q$BIT  -qlanglvl=stdc99 -qcpluscmt "
		fi
	;;
	#	HP-UX	--------------------------------------------------------------
	HP-UX)
		PRE_DEFINE=${PRE_DEFINE}" -DCOMPILE_DL_SDBAPIEXPORT -D_HPUX -D__SDB_BIG_ENDIAN -DNATIVE -D_POSIX_C_SOURCE=199506L "
		#PRE_DEFINE=${PRE_DEFINE}" -D_HPUX -D__BIG_ENDIAN "

		# cpu ���� Ȯ��
		CPUTYPE=`model|grep ia`

		if [ $IS_GCC -eq 1 ];
		then
			OPTION=" -fPIC "
			
			if [ -z "$CPUTYPE" ]
			then
				PRE_DEFINE=${PRE_DEFINE}" -DNO_HAVE_DLADDR "				
			else
				OPTION=${OPTION}" -mlp$BIT "
			fi
		else
			OPTION=" -Ae +u4 +z +DD"$BIT
			#OPTION=" +z -Ae +DD"$BIT
			if [ -z "$CPUTYPE" ];
			then
				PRE_DEFINE=${PRE_DEFINE}" -DNO_HAVE_DLADDR "
				OPTION=${OPTION}" +DA2.0W "
			fi
		fi	
	;;
	#	Linux	--------------------------------------------------------------
	Linux)
		#PRE_DEFINE=${PRE_DEFINE}" -DCOMPILE_DL_SDBAPIEXPORT -D_LINUX -D__LITTLE_ENDIAN "
		PRE_DEFINE=${PRE_DEFINE}" -DCOMPILE_DL_SDBAPIEXPORT -D_LINUX -D__SDB_LITTLE_ENDIAN "
		OPTION=" -m$BIT -fPIC "
	;;
	esac

	CFLAGS=" -DBIT_"$BIT$PRE_DEFINE$OPTMIZATION$OPTION
	echo $CFLAGS
	exit 0
}

#-------------------------------------------------------------------------
#	LDFLAGS�� ����
#-------------------------------------------------------------------------
GetLDFlags()
{
	IS_GCC=1
	if [ $1 -eq 1 ];
	then
		IS_GCC=1
	fi
	LDFLAGS=""
	DL_LIB=" -ldl "
	case $OS_TYPE
	in
	#	SunOS	--------------------------------------------------------------
	SunOS)
		if [ $IS_GCC -eq 1 ]
		then
			LDFLAGS=" -shared -Wl -lsocket -lnsl  "
		else
			LDFLAGS=" -G -lsocket -lnsl "
		fi
	;;
	#	AIX	--------------------------------------------------------------
	AIX)
		if [ $IS_GCC -eq 1 ]
		then
			LDFLAGS=" -shared -Wl "
		else
			LDFLAGS=" -G -berok -bM:SRE -bnoentry -bexpall "
		fi
	;;
	#	HP-UX	--------------------------------------------------------------
	HP-UX)
		# cpu ���� Ȯ��
		CPUTYPE=`model|grep ia`

		if [ $IS_GCC -eq 1 ]
		then
			LDFLAGS=" -shared -Wl "
		else
			LDFLAGS=" -b "		
		fi

		if [ -z "$CPUTYPE" ];
		then
			DL_LIB=""
		fi
	;;
	#	Linux	--------------------------------------------------------------
	Linux)
		LDFLAGS=" -shared -Wl "
	;;
	esac
	LDFLAGS=${LDFLAGS}" -lm "${DL_LIB}
	echo $LDFLAGS
	exit 0
}


case $1 in
-whereismake)
	WhereIsMake
	;;
-whereisgcc)
	WhereIsCC "gcc"
	;;
-whereiscc)
	WhereIsCC "cc"
	;;
-getcflags)
	if [ $# -ne 3 ];
	then
		Usage
	fi
	
	GetCflags "$2" "$3"
	;;
-getldflags)
	if [ $# -ne 2 ];
	then
		Usage
	fi
	GetLDFlags "$2"
	;;
-getkernelbits)
	GetKernelBits
	;;
*)
	Usage
	;;
esac





