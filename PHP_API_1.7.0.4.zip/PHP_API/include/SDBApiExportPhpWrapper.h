
#ifndef SDBAPI_INTERFACE_PHP_H_
#define SDBAPI_INTERFACE_PHP_H_

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <sys/types.h>
#include <string.h>

#include "SDBApiExport.h"
#include "php.h"
#include "php_ini.h"
#include "SAPI.h"
#include "standard/info.h"
#include "zend.h"
#include "zend_API.h"
#include "TSRM.h"

#ifndef ZEND_DEBUG
#define ZEND_DEBUG
#endif

#endif /* SDBAPI_INTERFACE_PHP_H_ */
