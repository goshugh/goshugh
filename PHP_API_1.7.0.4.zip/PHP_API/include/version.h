#ifndef _VERSIONHISTORY_H_
#define _VERSIONHISTORY_H_

#define VERSION_MAJOR 		"1"
#define VERSION_MINOR 		"7"
#define VERSION_BUILD 		"0"
#define VERSION_REVISION 	"3"
#define LAST_MODIFY_DATE __DATE__" "__TIME__

#define SDBAGENT_VERSION LAST_MODIFY_DATE" - "VERSION_MAJOR"."VERSION_MINOR"."VERSION_BUILD"."VERSION_REVISION


#endif		/*	 _VERSIONHISTORY_H_	*/

/* Version History ------------------------------------------------
 * 20120803 : Ver 1.7.0.2 : Makefile ���� �� ������ �����ϰ� ��. SHA �˰����� �߰�
 * 20150212 : Ver 1.7.0.3 : Add Function 
 *
 *
 *
 *
 *
 *
 ---------------------------------------------------------------------*/

