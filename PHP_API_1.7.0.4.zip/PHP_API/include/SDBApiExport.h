#ifndef _SDBAPIEXPORT_H_
#define _SDBAPIEXPORT_H_


#ifdef __cplusplus
extern "C" {
#endif	/*	__cplusplus	*/


#ifndef DLLEXPORT
#	if defined(WIN32)||defined(_WIN32)
#		ifdef _USRDLL
#			define DLLEXPORT __declspec(dllexport)
#		else
#			define DLLEXPORT __declspec(dllimport)
#		endif	/*	_USRDLL	*/
#	else
#			define DLLEXPORT
#	endif	/*	WIN32	*/
#endif	/*	DLLEXPORT	*/


#ifndef PPVOID
#define PPVOID void**
#endif

#ifndef HAVE_SDLOGLEVEL
#define HAVE_SDLOGLEVEL
	typedef enum 
	{
		SDLOGLEVEL_DEBUG = 1,
		SDLOGLEVEL_ERROR = 2,
		SDLOGLEVEL_CRIT	= 3
	}SDLOGLEVEL;
#endif
	/* Instance Init */
	/* Return Value 0 : SUCCESS, -1 : FAIL(0 ���� ���� ��) */
	DLLEXPORT int SDB_GetInstance(const char* dbIp, const unsigned short dbPort, const char* sdbSvrIp, const unsigned short sdbSvrPort );
	DLLEXPORT int SDB_GetInstanceHA(const char* dbIp, const unsigned short dbPort, 
		const char* sdbSvrIp1, const unsigned short sdbSvrPort1,
		const char* sdbSvrIp2, const unsigned short sdbSvrPort2);
	DLLEXPORT int SDB_GetInstanceDomain(const char* domainName, const char* sdbSvrIp, const unsigned short sdbSvrPort );
	DLLEXPORT int SDB_GetInstanceDomainHA(const char* domainName, 
		const char* sdbSvrIp1, const unsigned short sdbSvrPort1,
		const char* sdbSvrIp2, const unsigned short sdbSvrPort2 );

	/* ��� �Լ� */
	/* Base Function */
	DLLEXPORT char* SDB_Encrypt(const char* owner, const char* table, const char* column, char* pData, int pDataLen);
	DLLEXPORT char* SDB_Decrypt(const char* owner, const char* table, const char* column, char* eData, int eDataLen);

	/* KDB Version */
	DLLEXPORT char* SDB_EncryptNormal(char* pData);
	DLLEXPORT char* SDB_DecryptNormal(char* eData);
	/* KDB Version */
	DLLEXPORT char* SDB_EncryptJumin(char* pData);
	DLLEXPORT char* SDB_DecryptJumin(char* eData);

	/* Return Value uOut Length */
	/* Parameter Add Data Length */
	DLLEXPORT int SDB_Encrypt2(const char* owner, const char* table, const char* column, char* pData, int pDataLen, char* uOut);
	DLLEXPORT int SDB_Decrypt2(const char* owner, const char* table, const char* column, char* eData, int pDataLen, char* uOut);

	/* Auto Length Check */
	DLLEXPORT int SDB_Encrypt3(const char* owner, const char* table, const char* column, char* pData, char* uOut);
	DLLEXPORT int SDB_Decrypt3(const char* owner, const char* table, const char* column, char* eData, char* uOut);

	/* Auto Length Check */
	DLLEXPORT int SDB_EncryptDP(const char* owner, const char* table, const char* column, char* pData, char* uOut,int dpType);
	DLLEXPORT int SDB_DecryptDP(const char* owner, const char* table, const char* column, char* eData, char* uOut,int dpType);

	/* Parameter Add Data Length */
	DLLEXPORT int SDB_EncryptDP2(const char* owner, const char* table, const char* column, char* pData, int pDataLen, char* uOut,int dpType);	
	DLLEXPORT int SDB_DecryptDP2(const char* owner, const char* table, const char* column, char* eData, int eDataLen, char* uOut,int dpType);

	/* Use Config File -------------------------------------------------------------------------------------------------------------*/
	/* Auto Length Check */
	DLLEXPORT int SDB_EncryptDP3(const char* owner, const char* table, const char* column, char* pData, char* uOut);
	DLLEXPORT int SDB_DecryptDP3(const char* owner, const char* table, const char* column, char* eData, char* uOut);

	/* Parameter Add Data Length */
	DLLEXPORT int SDB_EncryptDP4(const char* owner, const char* table, const char* column, char* pData, int pDataLen, char* uOut);	
	DLLEXPORT int SDB_DecryptDP4(const char* owner, const char* table, const char* column, char* eData, int eDataLen, char* uOut);
	/* ---------------- -------------------------------------------------------------------------------------------------------------*/

	/* Extenstion Function : NULL Encrypt method */
	DLLEXPORT char* SDB_DecryptEx(const char* sKeyName, char* eData, int eDataLen, int nullChk);
	DLLEXPORT char* SDB_EncryptEx(const char* sKeyName, char* pData, int pDataLen, int nullChk);

	DLLEXPORT int SDB_EncryptEx2(const char* sKeyName, char* pData, int pDataLen, int nullChk, char* uOut);
	DLLEXPORT int SDB_DecryptEx2(const char* sKeyName, char* eData, int eDataLen, int nullChk, char* uOut);

	/* Extenstion Function SHA alg */
	DLLEXPORT int SDB_GetInstanceSha();
	DLLEXPORT int SDB_doDigest(char* pData, int pDataLen, char* outData);
	DLLEXPORT int SDB_doDigest256(char* pData, int pDataLen, char* output);
	DLLEXPORT char* SDB_EncryptSha256(char* pData);
	DLLEXPORT char* SDB_EncryptSha256_T1(char* pData);


	DLLEXPORT void SDB_Clear();
	DLLEXPORT char* SDB_GetLastErrorMsg();
	DLLEXPORT void SDB_SetLogging(const char* filename, SDLOGLEVEL logLevel);
	DLLEXPORT int SDB_GetLastErrorCode();
	DLLEXPORT int SDB_IsValidKey(const char* owner, const char* table, const char* column);


	/*DLEXPORT void SDBApi_SetLicensePath(char* path);*/

	/* moon's 121018 : memory free */
	DLLEXPORT void SDB_Free_UString(unsigned char* pdata);
	/* moon'e */

#ifdef __cplusplus
}
#endif	/*	__cplusplus	*/
#endif	/*	_SDBAPI_H_	*/

