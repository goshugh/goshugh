﻿<html>
<title> SDBApiExportPHP TEST </title>
<head>
</head>
<body>
<h5> SDBApiExportPHP TEST </h5>
<h2>SDB_GetInstance FUNCTION TEST</h2>
<?php
$now =time();
echo "test...$now<br>";
$retParam = -1;
$dname = "Agent_local";
$servip = "10.20.31.29";
$servport = 9003;
//프로젝트 수행시에는 한번 만 호출 할 수 있도록 GetInstance 호출 위치를 고려 해야 한다.
$retParam= sdb_getinstancedomain($dname, $servip, $servport);
if($retParam == -1) {
	echo "GetInstance Fail $retParam <br>";
	$result = sdb_getlasterrormsg();
	echo "Error Msg : $result <br>";
}
else {
	echo "GetInstance Success $retParam <br>";
}
//테이블 정보
$tbname = "TEST";
$schema = "TEST_TABLE";
$colname = "NAME";
?>
<h2> key Check </h2>
<?php
//키 검사
$ret = sdb_isvalidkey($schema, $tbname, $colname);
if($ret < 0 ) {
echo "Key is Not Valid....<br>";
}
else {
echo "Key is Valid....<br>";
}
?>
<h2> Encrypt Test </h2>
<?php
$pData = "qwertyuiop1234567890";
$pDataLen = strlen($pData);
//암호화 수횅
$encData = sdb_encrypt($schema, $tbname, $colname, $pData, $pDataLen);
if($encData == -99){
echo "Data is Not Encrypt.....errcode $encData <br>";
}
else {
echo "Data Encrypt value $encData <br>";
}
?>
<h2> Decrypt Test </h2>
<?php
$encDataLen = strlen($encData);
//복호화 수행
$decData = sdb_decrypt($schema, $tbname, $colname, $encData, $encDataLen);
if($decData == -99) {
echo "Data is Not Decrypt..... errcode $decData <br>";
}
else {
echo "Data Decrypt value $decData <br>";
}
?>
<h2> EncryptDP Test </h2>
<?php
$pDataDp = "qwertyuiop1234567890";
$pDataLenDp = strlen($pDataDp);
$encDataDp = sdb_encryptdp($schema, $tbname, $colname, $pDataDp, $pDataLenDp, 1);
if($encDataDp == -99){
echo "Data is Not EncryptDP.....errcode $encDataDp <br>";
}
else {
echo "Data EncryptDP value $encDataDp <br>";
}
?>
<h2> DecryptDP Test </h2>
<?php
$encDataLenDp = strlen($encDataDp);
//복호화 수행
$decDataDp = sdb_decryptdp($schema, $tbname, $colname, $encDataDp, $encDataLenDp,1);
if($decDataDp == -99) {
echo "Data is Not DecryptDP..... errcode $decDataDp <br>";
}
else {
echo "Data DecryptDP value $decDataDp <br>";
}
?>

<h2>  SHA1 Test </h2>
<?php
$pDataSha = "qwertyuiop1234567890";
$pDataLenSha = strlen($pDataSha);
//SHA암호화 수행
$encDataSha = sdb_doDigest($pDataSha, $pDataLenSha);
if($encDataSha == -99) {
echo "Data is Not SHA Encrypt..... errcode $encDataSha <br>";
}
else {
$encDataShaLen = strlen($encDataSha);
echo "Data SHA Encrypt value $encDataSha ($encDataShaLen)<br>";
}
?>

<h2>  SHA256 Test </h2>
<?php
$pDataSha2 = "qwertyuiop1234567890";
$pDataLenSha2 = strlen($pDataSha2);
//SHA256 암호화 수행
$encDataSha2 = sdb_doDigest256($pDataSha2, $pDataLenSha2);
if($encDataSha2 == -99) {
echo "Data is Not SHA Encrypt..... errcode $encDataSha2 <br>";
}
else {
$encDataShaLen2 = strlen($encDataSha2);
echo "Data SHA Encrypt value $encDataSha2 ($encDataShaLen2)<br>";
}
?>
<h2> SDBClear </h2>
<?php
//SDBApi 정보 초기화
//SDB_Clear();
?>
</body>
</html>
