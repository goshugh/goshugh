<?php
 phpinfo()
?>
