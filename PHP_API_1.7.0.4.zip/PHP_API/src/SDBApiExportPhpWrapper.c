/*
 * SDBApiExportPhpWrapper.c 
*/
/***************************************************************************************************************
* Modify JHKIM 20150212
* Modified List
* 20150212
*   - MOD : Version Display
*   - MOD : Addtional Function
****************************************************************************************************************/
#include "SDBApiExportPhpWrapper.h"

/*------------------------------------------------------------------------------
	declaration of functions to be exported
------------------------------------------------------------------------------*/
static ZEND_FUNCTION(sdb_dodigest);
static ZEND_FUNCTION(sdb_dodigest256);
static ZEND_FUNCTION(sdb_getinstance);
static ZEND_FUNCTION(sdb_getinstanceha);
static ZEND_FUNCTION(sdb_getinstancedomain);
static ZEND_FUNCTION(sdb_getinstancedomainha);
static ZEND_FUNCTION(sdb_isvalidkey);
static ZEND_FUNCTION(sdb_encrypt);
static ZEND_FUNCTION(sdb_encryptdp);
static ZEND_FUNCTION(sdb_decrypt);
static ZEND_FUNCTION(sdb_decryptdp);
static ZEND_FUNCTION(sdb_getlasterrormsg);
static ZEND_FUNCTION(sdb_clear);

static PHP_MINIT_FUNCTION(sdbapiexport);
static PHP_MSHUTDOWN_FUNCTION(sdbapiexport);
static PHP_MINFO_FUNCTION(sdbapiexport);
/*------------------------------------------------------------------------------
	declaration of functions
------------------------------------------------------------------------------*/
void php_sdbapiexport_initialize();
void php_sdbapiexport_shutdown();

/*------------------------------------------------------------------------------
	compiled function list
------------------------------------------------------------------------------*/
zend_function_entry sdbapiexport_functions[] =
{
    	ZEND_FE(sdb_dodigest, NULL)
	ZEND_FE(sdb_dodigest256, NULL)
	ZEND_FE(sdb_getinstance, NULL)
	ZEND_FE(sdb_getinstanceha, NULL)
        ZEND_FE(sdb_getinstancedomain, NULL)
        ZEND_FE(sdb_getinstancedomainha, NULL)
	ZEND_FE(sdb_isvalidkey, NULL)
	ZEND_FE(sdb_encrypt, NULL)
	ZEND_FE(sdb_encryptdp, NULL)
	ZEND_FE(sdb_decrypt, NULL)
	ZEND_FE(sdb_decryptdp, NULL)
	ZEND_FE(sdb_clear, NULL)
	ZEND_FE(sdb_getlasterrormsg, NULL)
	{NULL, NULL, NULL}
};

/*------------------------------------------------------------------------------
	compiled module information
------------------------------------------------------------------------------*/
zend_module_entry sdbapiexport_module_entry =
{
	STANDARD_MODULE_HEADER,
	"sdbapiexport",
	sdbapiexport_functions,
	PHP_MINIT(sdbapiexport),
	PHP_MSHUTDOWN(sdbapiexport),
	NULL,
	NULL,
	PHP_MINFO(sdbapiexport),
	"1.7.1.21",
	STANDARD_MODULE_PROPERTIES
};

#if COMPILE_DL_SDBAPIEXPORT
ZEND_GET_MODULE(sdbapiexport);
#endif

PHP_MINIT_FUNCTION(sdbapiexport)
{
	php_sdbapiexport_initialize();

	return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(sdbapiexport)
{
	php_sdbapiexport_shutdown();

	return SUCCESS;
}


PHP_MINFO_FUNCTION(sdbapiexport)
{
	php_info_print_table_start();
	php_info_print_table_row(2, "SDBAPI_Interface For PHP Support", "enabled" );
	php_info_print_table_row(2, "SDBAPI_Interface For PHP Version", "1.7.0.4" );
	php_info_print_table_row(2, "SDBAPI_Core Version","1.7.1.21");
	php_info_print_table_end();
}

void php_sdbapiexport_initialize(void)
{

}

void php_sdbapiexport_shutdown(void)
{
}

int enccolumnsize(int pDataLen)
{
        int encLen = 0;
        encLen = (int)(pDataLen*1.5);
        encLen = encLen + (16 - (encLen % 16));
        encLen = (encLen *4)/3 + 4 - (encLen%4);
        encLen += 16;
        return encLen;
}

ZEND_FUNCTION(sdb_dodigest)
{
	int nCode = 0;
#ifdef _PHP7_
	zend_string *pData = NULL;
#else
	char *pData = NULL;
	int nData = 0;
#endif
	char *outData = NULL;
	long pDataLen = 0;
	int bEncLen = 0;
	int ret = 0;

#ifdef _PHP7_
	if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SL", &pData, &pDataLen) != SUCCESS) {
		WRONG_PARAM_COUNT;
	}
#else
	if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sl", &pData, &nData, &pDataLen) != SUCCESS) {
		WRONG_PARAM_COUNT;
	}
#endif
	
	bEncLen = ((20*4)/3)+4;
	outData = (char*)malloc(bEncLen);
	memset(outData,0,bEncLen);

#ifdef _PHP7_
	ret = SDB_doDigest(pData->val, pDataLen, outData);
#else
	ret = SDB_doDigest(pData, pDataLen, outData);
#endif
	
	if (ret == -1){
		nCode = -99;
		free(outData);
		RETURN_LONG(nCode);
	}
	else {
#ifdef _PHP7_
		RETVAL_STRINGL(outData, ret);
#else
		RETVAL_STRINGL(outData, ret, 1);
#endif
		free(outData);
	}
	return;
}

ZEND_FUNCTION(sdb_dodigest256)
{
	int nCode = 0;
#ifdef _PHP7_
	zend_string *pData = NULL;
#else
	char *pData = NULL;
	int nData = 0;
#endif
	char *outData = NULL;
	long pDataLen = 0;
	int bEncLen = 0;
	int ret = 0;

#ifdef _PHP7_ 
	if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SL", &pData, &pDataLen) != SUCCESS) {
		WRONG_PARAM_COUNT;
	}
#else
	if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sl", &pData, &nData, &pDataLen) != SUCCESS) {
		WRONG_PARAM_COUNT;
	}
#endif
	
	bEncLen = ((32*4)/3)+4;
	outData = (char*)malloc(bEncLen);
	memset(outData,0,bEncLen);

#ifdef _PHP7_
	ret = SDB_doDigest256(pData->val, pDataLen, outData);
#else
	ret = SDB_doDigest256(pData, pDataLen, outData);
#endif
	
	if (ret == -1){
		nCode = -99;
		free(outData);
		RETURN_LONG(nCode);
	}
	else {
#ifdef _PHP7_
		RETVAL_STRINGL(outData, ret);
#else
		RETVAL_STRINGL(outData, ret, 1);
#endif
		free(outData);
	}
	return;

}

ZEND_FUNCTION(sdb_getinstance)
{
	   /* Comment 20120701 : parameter check Success */
		int ret = 0;
		long dbPort = 0;
		long sdbSvrPort = 0;
#ifdef _PHP7_
		zend_string *dbIp = NULL;
		zend_string *sdbSvrIp = NULL;
#else
		char *dbIp = NULL;
		int ndbIp = 0;
		char *sdbSvrIp = NULL;
		int nsdbSvrIp = 0;

#endif


#ifdef _PHP7_
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SLSL", &dbIp, &dbPort, &sdbSvrIp, &sdbSvrPort) != SUCCESS){
			WRONG_PARAM_COUNT;
		}

		ret = SDB_GetInstance(dbIp->val, dbPort, sdbSvrIp->val, sdbSvrPort);
		/* if (ret < 0) { ret = -99;} */
#else
		if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "slsl", &dbIp, &ndbIp, &dbPort, &sdbSvrIp, &nsdbSvrIp, &sdbSvrPort) != SUCCESS){
			WRONG_PARAM_COUNT;
		}


		ret = SDB_GetInstance(dbIp, dbPort, sdbSvrIp, sdbSvrPort);
		/* if (ret < 0) { ret = -99;} */
#endif

		RETURN_LONG(ret);
}

ZEND_FUNCTION(sdb_getinstanceha)
{
	int ret = 0;
	long dbPort = 0;
	long sdbSvrPort1 = 0;
	long sdbSvrPort2 = 0;

#ifdef _PHP7_
	zend_string *dbIp = NULL;
	zend_string *sdbSvrIp1 = NULL;
	zend_string *sdbSvrIp2 = NULL;
#else
	char *dbIp = NULL;
	int ndbIp = 0;
	char *sdbSvrIp1 = NULL;
	int nsdbSvrIp1 = 0;
	char *sdbSvrIp2 = NULL;
	int nsdbSvrIp2 = 0;
#endif

#ifdef _PHP7_
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SLSLSL", &dbIp, &dbPort, &sdbSvrIp1, &sdbSvrPort1, &sdbSvrIp2, &sdbSvrPort2) != SUCCESS){
		WRONG_PARAM_COUNT;
	}

	ret = SDB_GetInstanceHA(dbIp->val, dbPort, sdbSvrIp1->val, sdbSvrPort1, sdbSvrIp2->val, sdbSvrPort2);
	if (ret < 0) {	ret = -99; }

#else
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "slslsl", &dbIp, &ndbIp, &dbPort, &sdbSvrIp1, &nsdbSvrIp1, &sdbSvrPort1, &sdbSvrIp2, &nsdbSvrIp2, &sdbSvrPort2) != SUCCESS){
		WRONG_PARAM_COUNT;
	}

	ret = SDB_GetInstanceHA(dbIp, dbPort, sdbSvrIp1, sdbSvrPort1, sdbSvrIp2, sdbSvrPort2);
	if(ret < 0) { ret = -99;}
#endif

	RETURN_LONG(ret);
}

/*ADD JHKIM 20150212 */
ZEND_FUNCTION(sdb_getinstancedomain)
{
        long ret = 0;
        long sdbSvrPort = 0;

#ifdef _PHP7_
	zend_string *dname = NULL;
	zend_string *sdbSvrIp = NULL;
#else
        char *dname = NULL;
        int ndname = 0;
        char *sdbSvrIp = NULL;
        int nsdbSvrIp = 0;

#endif

#ifdef _PHP7_

        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSL", &dname, &sdbSvrIp, &sdbSvrPort) != SUCCESS){
                WRONG_PARAM_COUNT;
        }

        ret = SDB_GetInstanceDomain(dname->val, sdbSvrIp->val, sdbSvrPort);
#else
        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ssl", &dname, &ndname, &sdbSvrIp, &nsdbSvrIp, &sdbSvrPort) != SUCCESS){
                WRONG_PARAM_COUNT;
        }

        ret = SDB_GetInstanceDomain(dname, sdbSvrIp, sdbSvrPort);
#endif

        RETURN_LONG(ret);
}

ZEND_FUNCTION(sdb_getinstancedomainha)
{
        int ret = 0;
        long sdbSvrPort1 = 0;
	long sdbSvrPort2 = 0;

#ifdef _PHP7_
	zend_string *dname = NULL;
	zend_string *sdbSvrIp1 = NULL;
	zend_string *sdbSvrIp2 = NULL;
#else
        char *dname = NULL;
        int ndname = 0;
        char *sdbSvrIp1 = NULL;
        int nsdbSvrIp1 = 0;
        char *sdbSvrIp2 = NULL;
        int nsdbSvrIp2 = 0;
#endif

#ifdef _PHP7_
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSLSL", &dname, &sdbSvrIp1, &sdbSvrPort1, &sdbSvrIp2, &sdbSvrPort2) != SUCCESS){
                WRONG_PARAM_COUNT;
        }

        ret = SDB_GetInstanceDomainHA(dname->val, sdbSvrIp1->val, sdbSvrPort1, sdbSvrIp2->val, sdbSvrPort2);
        if (ret < 0) {  ret = -99; }
#else
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sslsl", &dname, &ndname, &sdbSvrIp1, &nsdbSvrIp1, &sdbSvrPort1, &sdbSvrIp2, &nsdbSvrIp2, &sdbSvrPort2) != SUCCESS){
                WRONG_PARAM_COUNT;
        }

        ret = SDB_GetInstanceDomainHA(dname, sdbSvrIp1, sdbSvrPort1, sdbSvrIp2, sdbSvrPort2);
        if (ret < 0) {  ret = -99; }
#endif

        RETURN_LONG(ret);
}


ZEND_FUNCTION(sdb_isvalidkey)
{
	int ret = 0;
#ifdef _PHP7_
	zend_string *owner = NULL;
	zend_string *table = NULL;
	zend_string *column = NULL;
#else
	char *owner = NULL;
	int nOwner = 0;
	char *table = NULL;
	int nTable = 0;
	char *column = NULL;
	int nColumn = 0;
#endif


#ifdef _PHP7_
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSS", &owner, &table, &column) != SUCCESS){
		WRONG_PARAM_COUNT;
	}

	ret = SDB_IsValidKey(owner->val, table->val, column->val);
#else
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sss", &owner, &nOwner, &table, &nTable, &column, &nColumn) != SUCCESS){
		WRONG_PARAM_COUNT;
	}

	ret = SDB_IsValidKey(owner, table, column);
#endif


	RETURN_LONG(ret);
}

ZEND_FUNCTION(sdb_encrypt)
{
	int nCode = 0;
#ifdef _PHP7_
	zend_string *owner = NULL;
	zend_string *table = NULL;
	zend_string *column = NULL;
	zend_string *pData = NULL;

#else
	char *owner = NULL;
	int nOwner = 0;
	char *table = NULL;
	int nTable = 0;
	char *column = NULL;
	int nColumn = 0;
	char *pData = NULL;
	int nData = 0;
#endif
	long pDataLen = 0;
	char *result = NULL;

#ifdef _PHP7_
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSSSL", &owner, &table, &column, &pData, &pDataLen) != SUCCESS){
		WRONG_PARAM_COUNT;
	}
	
	result = SDB_Encrypt(owner->val, table->val, column->val, pData->val, pDataLen);
#else
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ssssl", &owner, &nOwner, &table, &nTable, &column, &nColumn, &pData, &nData, &pDataLen) != SUCCESS){
		WRONG_PARAM_COUNT;
	}
	result = SDB_Encrypt(owner, table, column, pData, pDataLen);
#endif
	
	if (result == NULL) {
		nCode = -99;
		RETURN_LONG(nCode);
	}
	else {
#ifdef _PHP7_
		RETVAL_STRINGL(result, strlen(result));
#else
		RETVAL_STRINGL(result, strlen(result), 1);
#endif
	}
	return;
}

ZEND_FUNCTION(sdb_encryptdp)
{
        int nCode = 0;

#ifdef _PHP7_
	zend_string *owner = NULL;
	zend_string *table = NULL;
	zend_string *column = NULL;
	zend_string *pData = NULL;
#else
        char *owner = NULL;
        int nOwner = 0;
        char *table = NULL;
        int nTable = 0;
        char *column = NULL;
        int nColumn = 0;
        char *pData = NULL;
        int nData = 0;
#endif
        long pDataLen = 0;
	long dpType = 0;

	unsigned int ret = 0;
        char *eData = NULL;
	unsigned int eDataLen = 0;

#ifdef _PHP7_
        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSSSLL", &owner,  &table, &column, &pData, &pDataLen, &dpType) != SUCCESS){
                WRONG_PARAM_COUNT;
        }
#else
        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ssssll", &owner, &nOwner, &table, &nTable, &column, &nColumn, &pData, &nData, &pDataLen, &dpType) != SUCCESS){
                WRONG_PARAM_COUNT;
        }
#endif

	eDataLen = enccolumnsize(pDataLen);
	eData = (char*)malloc(eDataLen);
	memset(eData,0,eDataLen);
	
#ifdef _PHP7_
        ret = SDB_EncryptDP2(owner->val, table->val, column->val, pData->val, pDataLen, eData, dpType);
#else
        ret = SDB_EncryptDP2(owner, table, column, pData, pDataLen, eData, dpType);
#endif

        if (ret < 0 ) {
                nCode = -99;
		free(eData);
		eDataLen = 0;
                RETURN_LONG(nCode);
        }
        else {
#ifdef _PHP7_
                RETVAL_STRINGL(eData, ret);
#else
                RETVAL_STRINGL(eData, strlen(eData),  1);
#endif
        }
        return;
}

ZEND_FUNCTION(sdb_decrypt)
{
	int nCode = 0;
#ifdef _PHP7_
	zend_string *owner = NULL;
	zend_string *table = NULL;
	zend_string *column = NULL;
	zend_string *eData = NULL;
#else
	char *owner = NULL;
	int nOwner = 0;
	char *table = NULL;
	int nTable = 0;
	char *column = NULL;
	int nColumn = 0;
	char *eData = NULL;
	int nData = 0;
#endif
	long eDataLen = 0;
	char *result = NULL;

#ifdef _PHP7_
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSSSL",  &owner, &table, &column, &eData, &eDataLen) != SUCCESS){
		WRONG_PARAM_COUNT;
	}
	result = SDB_Decrypt(owner->val, table->val, column->val, eData->val, eDataLen);
	
#else
	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ssssl",  &owner, &nOwner, &table, &nTable, &column, &nColumn, &eData, &nData, &eDataLen) != SUCCESS){
		WRONG_PARAM_COUNT;
	}
	
	result = SDB_Decrypt(owner, table, column, eData, eDataLen);
#endif
	if (result == NULL) {
		nCode = -99;
		RETURN_LONG(nCode);
	}
	else {
#ifdef _PHP7_
		RETVAL_STRINGL(result, strlen(result));
#else
		RETVAL_STRINGL(result, strlen(result),  1);
#endif
	}
	return;
}

ZEND_FUNCTION(sdb_decryptdp)
{
        int nCode = 0;

#ifdef _PHP7_
	zend_string *owner = NULL;
	zend_string *table = NULL;
	zend_string *column = NULL;
	zend_string *eData = NULL;
#else
        char *owner = NULL;
        int nOwner = 0;
        char *table = NULL;
        int nTable = 0;
        char *column = NULL;
        int nColumn = 0;
        char *eData = NULL;
        int nData = 0;
#endif
        long eDataLen = 0;
        long dpType = 0;

        unsigned int ret = 0;
        char *pData = NULL;
        unsigned int pDataLen = 0;

#ifdef _PHP7_
        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SSSSLL", &owner, &table, &column, &eData, &eDataLen, &dpType) != SUCCESS){
                WRONG_PARAM_COUNT;
        }
#else
        if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ssssll", &owner, &nOwner, &table, &nTable, &column, &nColumn, &eData, &nData, &eDataLen, &dpType) != SUCCESS){
                WRONG_PARAM_COUNT;
        }

#endif

        pData = (char*)malloc(eDataLen);
        memset(pData,0,eDataLen);

#ifdef _PHP7_
        ret = SDB_DecryptDP2(owner->val, table->val, column->val, eData->val, eDataLen, pData, dpType);
#else
        ret = SDB_DecryptDP2(owner, table, column, eData, eDataLen, pData, dpType);
#endif

        if (ret < 0 ) {
                nCode = -99;
                free(pData);
                pDataLen = 0;
                RETURN_LONG(nCode);
        }
        else {

#ifdef _PHP7_
                RETVAL_STRINGL(pData, ret);
#else
                RETVAL_STRINGL(pData, strlen(pData),  1);
#endif

        }
        return;
}


ZEND_FUNCTION(sdb_clear)
{
	int result = 0;

	SDB_Clear();

	RETURN_LONG(result);
}

ZEND_FUNCTION(sdb_getlasterrormsg)
{
	char *errMsg = NULL;
	errMsg = SDB_GetLastErrorMsg();

#ifdef _PHP7_
	RETVAL_STRINGL(errMsg, strlen(errMsg));
#else
	RETVAL_STRINGL(errMsg, strlen(errMsg), 1);
#endif
	return;
}
