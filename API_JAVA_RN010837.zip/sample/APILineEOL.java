package com.ksign.securedb.api;

import com.ksign.securedb.api.util.SDBException;
import com.ksign.securedb.api.util.SDUtil;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class APILineEOL {
    private static APILineEOL apiTester = null;

    public static void main(String[] args) {
        if(apiTester == null) {
            apiTester = new APILineEOL();
        }

        try {
//            apiTester.doLineTest();
//            apiTester.doLineBulkTest();
//            apiTester.doLineBulkHeaderTest();
            apiTester.doFileLineTest();
//            apiTester.doFileLineSrcTest();
//            apiTester.doHeader();
//            apiTester.isEncryptedTest();
//            apiTester.doFileBlockTest();
        } catch(SDBException e) {
            e.printStackTrace();
            if(e.getResultCode() == 2001) {
                System.out.println("ERROR CODE : " + e.getResultCode() + "::" + e.getErrorMessage());
            }
            System.exit(0);
        }
    }

    private void doLineTest() throws SDBException {
        System.out.println(" [encryptCEVLine / decryptCEVLine] TEST START !");

        //encrypt line
        String cipherText = SDBCrypto.encryptCEVLine("test", "testtable", "name", "abcdefg", null);
        System.out.println("  encryptCEVLine : " + cipherText);

        //decrypt line
        System.out.println("  decryptCEVLine : " + SDBCrypto.decryptCEVLine("test", "testtable", "name", cipherText, null));

        //encrypt line already encryptped. decrypt line.
        String plainText = SDBCrypto.encryptCEVLine("test", "testtable", "name", "uRXaw5umoB9ghea4Q3hTqA==", null);
        System.out.println("  encryptCEVLine : " + plainText);
        System.out.println("  decryptCEVLine : " + SDBCrypto.decryptCEVLine("test", "testtable", "name", cipherText, null));

        System.out.println(" [encryptCEVLine / decryptCEVLine] TEST END !");
    }

    private void doLineBulkTest() throws SDBException {
        System.out.println(" [encryptCEVLineBulk / decryptCEVLineBulk] TEST START !");

        // enc dec data init
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("abcdef");
        arrayList.add("8VllOy9kdp6IgHLFT57+DA==");
        arrayList.add("zxcv");
        arrayList.add("uRXaw5umoB9ghea4Q3hTqA==");

        // enc line bulk test
        ArrayList<String> cipherTexts = SDBCrypto.encryptCEVLineBulk("test", "testtable", "name", arrayList, null);
        System.out.println(" - encryptCEVLineBulk result");
        for(String cihperText : cipherTexts) {
            System.out.println("  -" + cihperText);
        }

        // dec line bulk test
        ArrayList<String> plainTexts = SDBCrypto.decryptCEVLineBulk("test", "testtable", "name", cipherTexts, null);
        System.out.println(" - decryptCEVLineBulk result");
        for(String plainText : plainTexts) {
            System.out.println("  -" + plainText);
        }

        System.out.println(" [encryptCEVLineBulk / decryptCEVLineBulk] TEST END !");
    }

    private void doLineBulkHeaderTest() throws SDBException {
        System.out.println(" [encryptCEVLineBulkHeader / decryptCEVLineBulkHeader] TEST START !");

        String mainPath = "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/";
        String fileName = "SAMTEST.txt";

        // enc dec data init
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("abcdef");
        arrayList.add("8VllOy9kdp6IgHLFT57+DA==");
        arrayList.add("zxcv");
        arrayList.add("uRXaw5umoB9ghea4Q3hTqA==");

        // enc line bulk test
        ArrayList<String> cipherTexts = SDBCrypto.encryptCEVLineBulk("JAPS", "TESTTABLE", "ONE", arrayList, null);
        System.out.println(" - encryptCEVLineBulkHeader result");
        for(String cihperText : cipherTexts) {
            System.out.println("  -" + cihperText);
        }

        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(mainPath + fileName));
            for(String cihperText : cipherTexts) {
                bw.write(cihperText);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bw != null) { try { bw.close(); } catch (IOException e) { e.printStackTrace(); } }
        }

        SDBCrypto.addHeader(mainPath + fileName);
        SDBCrypto.delHeader(mainPath + fileName);


        // dec line bulk test
//        ArrayList<String> plainTexts = SDBCrypto.decryptCEVLineBulk("test", "testtable", "name", cipherTexts, null);
//        System.out.println(" - decryptCEVLineBulkHeader result");
//        for(String plainText : plainTexts) {
//            System.out.println("  -" + plainText);
//        }

        System.out.println(" [encryptCEVLineBulkHeader / decryptCEVLineBulkHeader] TEST END !");
    }

    private void doFileLineTest() throws SDBException {
        String mainPath = "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/";
//        String fileName = "SAMTESTNEW.txt";
        String fileName = "customer.tbl.149999997";
        System.out.println(" [encryptCEVFileLine / decryptCEVFileLine] TEST START !");

        // enc file line test
//        boolean encRes = SDBCrypto.encryptCEVFileLine(mainPath + fileName, mainPath + fileName + "_ok", "JAPS", "TESTTABLE", "ONE", false);
        boolean encRes = SDBCrypto.encryptCEVFileLine(mainPath + fileName, null, "JAPS", "TESTTABLE", "ONE", true);
        System.out.println("  encryptCEVFileLine result : " + encRes);


//        getChractor(mainPath + fileName + "_org");
//        getChractor(mainPath + fileName);



        // dec file line test
        boolean decRes = SDBCrypto.decryptCEVFileLine(mainPath + fileName, null, "JAPS", "TESTTABLE", "ONE", true);
        System.out.println("  decryptCEVFileLine result : " + decRes);

//        getChractor(mainPath + fileName + "_enc");
//        getChractor(mainPath + fileName);

        System.out.println(" [encryptCEVFileLine / decryptCEVFileLine] TEST END !");
    }

    private void doFileLineSrcTest() throws SDBException {
        String mainPath = "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/";
//        String fileName = "SAMTESTNEW.txt";
        String fileName = "customer.tbl.149999997";
        System.out.println(" [encryptCEVFileLine / decryptCEVFileLine] TEST START !");

        // enc file line src test
//        boolean encRes = SDBCrypto.encryptCEVFileLineSrc(mainPath + fileName, "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/SAMTESTNEW.txt_enc", "JAPS", "TESTTABLE", "ONE");
//        System.out.println("  encryptCEVFileLine result : " + encRes);
//        getChractor(mainPath + fileName + "_org");
//        getChractor(mainPath + fileName);



        // enc file line src test
        boolean decRes = SDBCrypto.decryptCEVFileLineSrc("/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/SAMTESTNEW.txt_enc", "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/SAMTESTNEW.txt_org", "JAPS", "TESTTABLE", "ONE");
        System.out.println("  decryptCEVFileLine result : " + decRes);
//        getChractor(mainPath + fileName + "_enc");
//        getChractor(mainPath + fileName);

        System.out.println(" [encryptCEVFileLine / decryptCEVFileLine] TEST END !");
    }

    private void doFileBlockTest() throws SDBException {
        String mainPath = "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/";
//        String fileName = "bmw.jpg";
        String fileName = "customer.tbl.149999997";
        System.out.println(" [encryptCEVFileBlock / decryptCEVFileBlock] TEST START !");

        // enc file line test
//        boolean encRes = SDBCrypto.encryptCEVFileBlock(mainPath + fileName, null, "JAPS", "TESTTABLE", "ONE", false);
//        System.out.println("  encryptCEVFileBlock result : " + encRes);

//        getChractor(mainPath + fileName + "_org");
//        getChractor(mainPath + fileName);

        // dec file line test
        boolean decRes = SDBCrypto.decryptCEVFileBlock(mainPath + fileName, null, "JAPS", "TESTTABLE", "ONE", false);
        System.out.println("  decryptCEVFileBlock result : " + decRes);

//        getChractor(mainPath + fileName + "_enc");
//        getChractor(mainPath + fileName);

        System.out.println(" [encryptCEVFileBlock / decryptCEVFileBlock] TEST END !");
    }

    private void isEncryptedTest() throws SDBException {
//        boolean abc = SDBCrypto.isEncryptedFile("/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/bmw.jpg_enc");
        boolean abc = SDBCrypto.isEncryptedFile("/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/customer.tbl.149999997");
        System.out.println(abc);

//        String cipherText = SDBCrypto.encryptCEVLine("JAPS", "TESTTABLE", "ONE", "abcdefg", null);
//        System.out.println("  encryptCEVLine : " + cipherText);
//        boolean cba = new SDBCrypto().isEncryptedData("JAPS", "TESTTABLE", "ONE", cipherText);
//        System.out.println(cba);
//
//        boolean cbad = new SDBCrypto().isEncryptedData("JAPS", "TESTTABLE", "ONE", "cipherText");
//        System.out.println(cbad);
    }

    private void doHeader() throws SDBException {
        String mainPath = "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/";
//        String fileName = "SAMTESTNEW.txt";
        String fileName = "customer.tbl.149999997";
        System.out.println(SDBCrypto.addHeader(mainPath + fileName));
//        System.out.println(SDBCrypto.delHeader(mainPath + fileName));
    }


    // CRLF HEX �� Ȯ��
    private void getChractor(String file) throws SDBException {
        System.out.println("Get Charactor Target File : " + file);
        SDBCrypto.getCharactor(file);
        System.out.println();
    }
}
