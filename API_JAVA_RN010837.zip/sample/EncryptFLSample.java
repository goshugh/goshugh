import com.ksign.securedb.api.SDBCrypto;

public class EncryptFLSample {

	public String keyName = "SCHEMA.TABLE.COLUMN";
	public String plainText = "1234561234567";
	public String cipherText = null;
	
	/**
	 * @Desc	: encryptFL / decryptFL Sample
	 * @Method	: main
	 * @param args
	 */
	public static void main(String[] args) {
		EncryptFLSample sample = new EncryptFLSample();
		sample.doEncTest();
		sample.doDecTest();
	}
	
	private void doEncTest() {
		try {
			cipherText = SDBCrypto.encryptFL(keyName, plainText);
			System.out.println("��ȣȭ : [ " + cipherText + " ]");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void doDecTest() {
		try {
			plainText = SDBCrypto.decryptFL(keyName, cipherText);
			System.out.println("��ȣȭ : [ " + plainText + " ]");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}