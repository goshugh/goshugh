 import java.util.Map;

import com.ksign.securedb.api.SDBCrypto;


public class APICryptoInfo {
public static void main(String[] args) throws Exception {
SDBCrypto crypto = SDBCrypto.getInstanceDomain("SECURE", "10.20.31.29", 9003);

String encKey = crypto.getEncKey();
System.out.println(encKey);


byte[] enc = crypto.encrypt("TEST_SECURE.ALG.SEED", "abcde".getBytes()); 
byte[] dec = crypto.decrypt("TEST_SECURE.ALG.SEED", enc);
System.out.println(new String(dec));


int size = crypto.getPaddingSize("TEST_SECURE.ALG.SEED");
System.out.println(size);

Map<String, String> map = crypto.getCryptoInfo("TEST_SECURE.ALG.SEED");
System.out.println(map.get("company"));

}
}