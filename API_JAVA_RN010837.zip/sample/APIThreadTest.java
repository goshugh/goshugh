
import com.ksign.securedb.api.SDBCrypto;
//import com.ksign.securedb.api.crypto.CuBASE64;
//import com.ksign.securedb.api.util.SDUtil;
//import com.ksign.securedb.api.util.APIConf;


import java.net.*;
import java.util.HashMap;
import java.util.Hashtable;

public class APIThreadTest {
	
	//������ ���� ����
	final static int ThreadCnt = 1;
	
	

    public static void main(String[] args) throws Exception {	
    	doStart();
    	
    }
    
    public static void doStart() throws Exception {
  //���� ��� ���� open
//    	SDBCrypto crypto = SDBCrypto.getInstanceDomain("ORACLE9i_121", "10.10.11.121", 29003);
//    	if(crypto == null) {
//    		System.out.println("Fail Get Instance.....");
//    		return;
//    	}

    	for(int i = 0 ; i < ThreadCnt ; i++) {
    		SDBEncryptThread sdbEncThr = new SDBEncryptThread();
    		System.out.println("Thread [" + i + "] running.....");
    		 //���� ��� ���� open
    		//sdbEncThr.EncStart(crypto, i+1);
    		sdbEncThr.EncStart(i+1);
    	} 
    }  
}

class SDBEncryptThread implements Runnable {

	private SDBCrypto encIns = null;
	private int seqNum = 0;
	//��ȣȭ Ƚ�� ����
	final static int MAXCOUNT = 1000;
	String encData = null;
	String decData = null;
	//��ȣȭ �� ��å ���� ����
	String schema = "KSIGN";
	String table = "TB_ALG";
	String column = "ARIA256";
	String pData = "1234567890wertyuiop!@#$A%";
	private boolean flag = true;
	
	public void EncStart(SDBCrypto crypto, int num){
		this.encIns = crypto;
		this.seqNum = num; 
		Thread thr = new Thread(this);
		thr.start();
	}
	
	
	public void EncStart(int num){
		this.seqNum = num; 
		Thread thr = new Thread(this);
		thr.start();
	}
	
	public boolean chkflag()
	{
		return this.flag;
	}
	
	public void run() {
		// TODO Auto-generated method stub

		
		try {
			 //���� ��� ���� open		
//	    	if(encIns == null) {
//	    		System.out.println("Fail Get Instance.....");
//	    		return;
//	    	}
//   	
		/* �� �� �Է� */     
	    
		long encstarttime = System.currentTimeMillis();
		for(int i=0;i< MAXCOUNT;i++) {
			 //���� ��� ���� open
			//encData = encIns.encrypt(schema, table, column, pData);
			encData = SDBCrypto.encryptCEV(schema, table, column, pData);
			if(encData == null) {
				System.out.println("Fail to Encrypt Data.........");
				return;
			}
		}
   		long encendtime = System.currentTimeMillis();
	    System.out.println("["+seqNum+"]ENC Time : " + (encendtime - encstarttime)*0.001 + "sec");
	    Thread.sleep(0);
 
    }
    catch(Exception e){
    	e.printStackTrace();
    }
		
  }
	
}   

