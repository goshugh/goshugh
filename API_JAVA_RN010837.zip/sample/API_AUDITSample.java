public class API_AUDITSample {

	/**
	 * @param args
	 * @throws SDBException 
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
    	String objName = "FTC.QC01_AGRT.F_SEED_ALG";
    	String encdata = null;
   	
    	try {
    		
    		SDBCrypto crypto = new SDBCrypto();
    		crypto = SDBCrypto.getInstance("10.20.31.200", 1521, "10.20.31.200", 9003);
    		if(crypto == null) {
    			return;
    		}
    		
    		if(crypto.do_AuditInit("C:\\KSIGNSDBAPICONF\\") == false) {
    			System.out.println("Fail Init Auditor ");
    			return;
    		}
    		
    		for(int i=0; i < 10; i++) {
    			System.out.println("audit write ["+i+"]");
    			if(crypto.do_Audit(objName, "SELECT", true, null)== false) {
    				System.out.println("Fail write Audit");
    				break;
    			}
    			Thread.sleep(10000);
    		}
    		
    	}catch(Exception e) {
    		
    	}
	}
}