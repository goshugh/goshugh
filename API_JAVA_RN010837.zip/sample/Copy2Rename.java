package com.ksign.securedb.api;

import com.ksign.securedb.api.util.SDBException;
import com.ksign.securedb.api.util.SDUtil;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Copy2Rename {
    private static Copy2Rename apiTester = null;

    public static void main(String[] args) {
        if(apiTester == null) {
            apiTester = new Copy2Rename();
        }

        try {
            apiTester.doCopy2Rename();
//            apiTester.doHeader();
        } catch(SDBException e) {
            e.printStackTrace();
            if(e.getResultCode() == 2001) {
                System.out.println("ERROR CODE : " + e.getResultCode() + "::" + e.getErrorMessage());
            }
            System.exit(0);
        }
    }

    private void doCopy2Rename() throws SDBException {
        String mainPath = "/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/";
//        String fileName = "SAMTESTNEW.txt";
        String fileName = "customer.tbl.149999997";
        System.out.println(" [encrypFileCEV / decryptFileCEV] TEST START !");

        // enc file test
        boolean encRes = SDBCrypto.encryptFileCEV(mainPath + fileName, "/home/dbsec/KSignSecureDB_CC/JAP_180108/target/customer.tbl.149999997", "JAPS.TESTTABLE.ONE");
//        boolean encRes = SDBCrypto.encryptFileCEV(mainPath + fileName,"JAPS.TESTTABLE.ONE");
        System.out.println("  encryptFileCEV result : " + encRes);


        // dec file line src test
//        boolean decRes = SDBCrypto.decryptFileCEV("/home/dbsec/KSignSecureDB_CC/JAP_180108/target/customer.tbl.149999997", "/home/dbsec/KSignSecureDB_CC/JAP_180108/decrypt/customer.tbl.149999997", "JAPS.TESTTABLE.ONE");
//        boolean decRes = SDBCrypto.decryptFileCEV("/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/customer.tbl.149999997", "JAPS.TESTTABLE.ONE");
//        System.out.println("  decryptFileCEV result : " + decRes);

        System.out.println(" [encryptFileCEV / decryptFileCEV] TEST END !");
    }

    private void doHeader() throws SDBException {
        boolean resADD = SDBCrypto.addHeader("/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/customer.tbl.149999997");
        System.out.println("=== Do Header - addheader RES :: " + resADD);
//
//        boolean resDEL = SDBCrypto.delHeader("/home/dbsec/KSignSecureDB_CC/JAP_180108/testSpace/customer.tbl.149999997");
//        System.out.println("=== Do Header - addheader RES :: " + resDEL);
    }
}
