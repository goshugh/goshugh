package etc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ksign.securedb.api.SDBCrypto;
import com.ksign.securedb.api.util.SDBException;




public class ApiBlobTest {

	SDBCrypto crypto = null;
	public static void main(String[] args) throws Exception{
		new ApiBlobTest().testStart();
	}

	private  void testStart() throws Exception {
		//initAPI();
		select();
		//insert();
	}

	private void initAPI() throws Exception {
		try {
			crypto = SDBCrypto.getInstance("10.20.150.156",1521, "10.20.150.156",9003, "10.20.150.156", 9003);
		} catch (SDBException e) {
			e.printStackTrace();
			throw e;
		}
	}



	private void insert() throws Exception{

		Connection con = getConnection();
		PreparedStatement ps;
		ResultSet rs;
		InputStream in = null;
		OutputStream out = null;
		StringBuffer sqlInsert = new StringBuffer();
		sqlInsert.append(" INSERT INTO SDB_BLOB_TEMP ");
		sqlInsert.append(" (FILE_NAME, FILE_DATA ) ");
		sqlInsert.append(" values(?, EMPTY_BLOB()) ");

		StringBuffer sqlSelect = new StringBuffer();
		sqlSelect.append(" SELECT FILE_DATA ");
		sqlSelect.append(" FROM SDB_BLOB_TEMP ");
		sqlSelect.append(" WHERE FILE_NAME=? FOR UPDATE");

		try{
			con.setAutoCommit(false);
			ps = con.prepareStatement(sqlInsert.toString());
			ps.setString(1, "WITH.mp4");
			ps.executeUpdate();

			ps = con.prepareStatement(sqlSelect.toString());
			ps.setString(1, "WITH.mp4");
			rs = ps.executeQuery();

			File file = null;
			if(rs.next()){
				Blob tmpBlob = rs.getBlob(1);
				try{
					file = new File("D:\\TEST\\WITH.mp4");
					in = new FileInputStream(file);
					out = tmpBlob.setBinaryStream(1L);
					//crypto.encrypt("TEST", "BLOB_TEST","PHOTO", in, out);
					SDBCrypto.encryptBlobCEV("TEST", "BLOB_TEST","PHOTO", in, out);
					 
				}catch (java.io.FileNotFoundException fe) {
					System.err.println (file.getName()
							+ " ������ �������� �ʽ��ϴ�.");
				}finally{
					if(in != null) in.close();
					if(out != null) out.close();

					con.commit();
					con.close();
				}
				
			}
			System.out.println("�����Ͻ� " + file.getName()
					+ " ������ blobtest ���̺��� "
					+ " �����Ͽ����ϴ�.");
			System.out.println("�����ͺ��̽��� ������ ������ ��ȸ�ϴ� "
					+ "������ ��������.");

		}catch(Exception e){
			System.out.println("Exception�� �߻��߽��ϴ�."
					+ " �ڼ��� ������ ������ �����ϴ�.");
			System.out.println(e.toString());

		}

	}


	private void select() throws Exception{

		Connection con = getConnection();
		PreparedStatement ps;
		ResultSet rs;
		InputStream in = null;
		OutputStream out = null;

	/*	StringBuffer sqlSelect = new StringBuffer();
		sqlSelect.append(" select PHOTO from sdb_blob_test where name = 'Penguins' ");*/

		StringBuffer sqlSelect = new StringBuffer();
		sqlSelect.append(" SELECT FILE_DATA ");
		sqlSelect.append(" FROM SDB_BLOB_TEMP ");
		sqlSelect.append(" WHERE FILE_NAME='rea.txt'");

		
		try{
			 
			 

			ps = con.prepareStatement(sqlSelect.toString());
			rs = ps.executeQuery();

			File file = null;
			if(rs.next()){
				Blob tmpBlob = rs.getBlob(1);
				try{
					file = new File("D:\\TEST\\temp.txt");
					if(!file.isFile()){
						file.createNewFile();
					}
					out = new FileOutputStream(file);
					in = tmpBlob.getBinaryStream();
					in = null;
//					copy(in,out);
					//crypto.decrypt("TEST", "BLOB_TEST","PHOTO", in, out);
					SDBCrypto.decryptBlobCEV("TEST", "BLOB_TEST","PHOTO", in, out);
					
					 
				}catch (java.io.FileNotFoundException fe) {
					System.err.println (file.getName()
							+ " ������ �������� �ʽ��ϴ�.");
				}finally{
					
					if(in != null) in.close();
					if(out != null){ 
						out.flush();
					out.close();}


				}
			}
			System.out.println("�����Ͻ� " + file.getName()
					+ " ������ blobtest ���̺��� "
					+ " �����Ͽ����ϴ�.");
			System.out.println("�����ͺ��̽��� ������ ������ ��ȸ�ϴ� "
					+ "������ ��������.");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Exception�� �߻��߽��ϴ�."
					+ " �ڼ��� ������ ������ �����ϴ�.");
			System.out.println(e.toString());

		}

	}
	
	private void selectQueryTest() throws Exception {
		Connection con = getConnection();
		PreparedStatement ps;		
		ResultSet rs;

		ps = con.prepareStatement("select FILEDATA from TEST_BLOB2 ");
		rs = ps.executeQuery();
		rs.next();
		Blob input =rs.getBlob(1);
		ps = con.prepareStatement("select FILEDATA from TEST_BLOB for update");
		rs = ps.executeQuery();
		rs.next();
		Blob output =rs.getBlob(1);
		//crypto.encrypt(tableOwner, tableName, columnName, input, output) ;
		rs.close();
		ps.close();
		con.close();
	}


private void copy(InputStream in, OutputStream out){
	int bufferSize = 5484;
	byte[] buffer = new byte[bufferSize];
	int read =0 ;
	try {
		while((read = in.read(buffer))>-1){
			out.write(buffer, 0, read);
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

	public   Connection getConnection() throws Exception {
		Connection connection = null;
		try {
			java.lang.Class.forName("oracle.jdbc.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.20.150.156:1521:ora11", "test", "test");
		} catch (Exception e) {
			throw e;
		}
		return connection;
	}


	private byte[] trimData(byte[] buffer, int readSize) {
		byte[] result = null;
		if(readSize == buffer.length){
			result = buffer;
		}else if(readSize <= 0){
			result =  null;
		}else{
			result = new byte[readSize];
			System.arraycopy(buffer, 0, result, 0, readSize);
		}
		return result;
	}

}
