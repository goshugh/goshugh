package test;

import com.ksign.securedb.api.SDBCrypto;

public class EncryptDPFileTest {

	public static void main(String[] args) {
		EncryptDPFileTest test = new EncryptDPFileTest();
		test.doTest();
	}

	private void doTest() {
		SDBCrypto crypto = new SDBCrypto();		
		boolean res = false;
		try {
//			crypto = SDBCrypto.getInstanceDomain("test", "00.00.00.00", 9003);
			crypto = SDBCrypto.getInstance("11.11.11.11", 1521, "00.00.00.00", 9003);
			
//			res = crypto.encryptDPFile("test/test.txt", "SOYOUNG.HITEST.NAME", true, 2);
//			System.out.println(res);
			
//			res = crypto.decryptDPFile("test/test.txt", "SOYOUNG.HITEST.NAME", false, 2, true);
//			System.out.println(res);
			
//			res = crypto.encryptDPFile("test/test.txt", "test/test_enc.txt", "SOYOUNG.HITEST.NAME", true, 2);
//			System.out.println(res);
			
//			res = crypto.decryptDPFile("test/test_enc.txt", "test/test_dec.txt", "SOYOUNG.HITEST.NAME", true, 2, true);
//			System.out.println(res);
			
			res = crypto.encryptDPFile("test/test_enc.txt", "test/test_encc.txt", "test/backup/", "SOYOUNG.HITEST.NAME", true, 2); 
			System.out.println(res);
			
			res = crypto.decryptDPFile("test/test_dec.txt", "test/test_decc.txt", "test/backup/", "SOYOUNG.HITEST.NAME", true, 2, true);
			System.out.println(res);
			
			
			// ���� ���߾�ȣȭ ���� check �Լ� : checkEncFile(String filename)
			res = SDBCrypto.checkEncFile("test/test_enc.txt");
			if(res) {
				System.out.println("result : Encrypted.");
			} else {
				System.out.println("result : Not encrypted.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
