package com.ksign.securedb.api;

public class SaltyTest {

	public static void main(String[] args) {
		try {

//		1. [Salt Hash Test]
//		saltHashTestMain();





//		2. [Iterate Salt Hash Test]
//		iterateSaltHashTestMain();


//		performanceTest();




//		3. [Iterate Salt Hash Client & Server Test]
			iterateSaltHashClientToServerTestMain();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}






	/**
	 * [Salt Hash Test]
	 * 1. digestSaltHash의 사용 샘플 코드.
	 * 2. checkSaltHash의 사용 샘플 코드.
	 **/
	private static void saltHashTestMain() throws Exception {

		digestSaltHashTest();


		checkSaltHashTest();

	}


	private static void digestSaltHashTest() throws Exception {
		String data = "abcd";

		String resultData = SDBCrypto.digestSaltHash(data);
		System.out.println("result :: " + resultData);
	}

	private static void checkSaltHashTest() throws Exception {
		String data1 = "abcd";
		String data2 = "abcc";
		String saltyHash = "Og4NGVv/2tLWJzi87mqtdnNMLuDVoKhqXKAAkLkRQq/1E3JNg+xcoeRzZUnpNPPxSQ==";

		boolean result1 = SDBCrypto.checkSaltHash(data1, saltyHash);
		boolean result2 = SDBCrypto.checkSaltHash(data2, saltyHash);

		System.out.println("result1 :: " + result1); // > true
		System.out.println("result2 :: " + result2); // > false
	}











	/**
	 * [Key Derivation Function Hash Test]
	 * 1. digestIterateSaltHash의 사용 샘플 코드.
	 * 2. isIterateSaltHashed의 사용 샘플 코드.
	 * 3. checkIterateSaltHash의 사용 샘플 코드.
	 **/
	public static void iterateSaltHashTestMain() throws Exception {

		digestIterateSaltHashTest();


//		isIterateSaltHashedTest();


		checkIterateSaltHashTest();

	}

	private static final String originalData1 = "abcd";
	private static String result_Data;
	private static String result_1passedData;
	private static String result_2passedData;
	private static String result_3passedData;

	private static final String originalData2 = "abcc";
	private static String result_Data2;

	private static void digestIterateSaltHashTest() throws Exception {


		System.out.println("[digestIterateSaltHash TEST 시작]");
		System.out.println(" > Hash를 여러번 사용할 때의 결과값 출력 테스트입니다.");
		System.out.println();


		System.out.println(" # 'abcd'를 1번 IterateSaltHash 합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash(originalData1);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();


		System.out.println(" # 'abcd'를 2번 IterateSaltHash 합니다.");
		result_1passedData = SDBCrypto.digestIterateSaltHash(result_Data);
		System.out.println(" - result_1passedData :: " + result_1passedData);
		System.out.println();


		System.out.println(" # 'abcd'를 3번 IterateSaltHash 합니다.");
		result_2passedData = SDBCrypto.digestIterateSaltHash(result_1passedData);
		System.out.println(" - result_2passedData :: " + result_2passedData);
		System.out.println();

		System.out.println(" # 'abcd'를 4번 IterateSaltHash 합니다.");
		result_3passedData = SDBCrypto.digestIterateSaltHash(result_2passedData);
		System.out.println(" - result_3passedData :: " + result_3passedData);
		System.out.println();


		System.out.println(" # 'abcc'를 IterateSaltHash 합니다.");
		result_Data2 = SDBCrypto.digestIterateSaltHash(originalData2);
		System.out.println(" - result_Data2 :: " + result_Data2);
		System.out.println();

		System.out.println();
		System.out.println();
	}

	private static void isIterateSaltHashedTest() throws Exception {

		System.out.println("[isIterateSaltHashed TEST 시작]");
		System.out.println(" > IterateSaltHash를 통해 Hashing된 값인지 판별하는 테스트입니다.");
		System.out.println();

		System.out.println(" # 'abcd'를 그대로 넣어 테스트합니다.");
		System.out.println(SDBCrypto.isIterateSaltHashed(originalData1)); // > false
		System.out.println();

		System.out.println(" # 'abcd'를 1번 IterateSaltHash한 결과를 넣어 테스트합니다.");
		System.out.println(SDBCrypto.isIterateSaltHashed(result_Data)); // > true
		System.out.println();

		System.out.println(" # 'abcd'를 2번 IterateSaltHash한 결과를 넣어 테스트합니다.");
		System.out.println(SDBCrypto.isIterateSaltHashed(result_1passedData)); // > true
		System.out.println();

		System.out.println(" # 'abcd'를 3번 IterateSaltHash한 결과를 넣어 테스트합니다.");
		System.out.println(SDBCrypto.isIterateSaltHashed(result_2passedData)); // > true
		System.out.println();

		System.out.println(" # 'abcd'를 4번 IterateSaltHash한 결과를 넣어 테스트합니다.");
		System.out.println(SDBCrypto.isIterateSaltHashed(result_3passedData)); // > true
		System.out.println();

		System.out.println(" # 'abcc'를 그대로 넣어 테스트합니다.");
		System.out.println(SDBCrypto.isIterateSaltHashed(result_Data2)); // > true
		System.out.println();

		System.out.println();
		System.out.println();
	}

	private static void checkIterateSaltHashTest() throws Exception {

		System.out.println("[checkIterateSaltHash TEST 시작]");
		System.out.println(" > IterateSaltHash된 값 B, B와 같은 값인지 검증하려는 A, A와 B를 검증하는 테스트입니다.");
		System.out.println();

		System.out.println(" # 'abcd'와 'abcd'를 1번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData1, result_Data)); // > true
		System.out.println();

		System.out.println(" # 'abcd'와 'abcd'를 2번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData1, result_1passedData)); // > true
		System.out.println();

		System.out.println(" # 'abcd'와 'abcd'를 3번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData1, result_2passedData)); // > true
		System.out.println();

		System.out.println(" # 'abcd'와 'abcd'를 4번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData1, result_3passedData)); // > true
		System.out.println();

		System.out.println(" # 'abcc'와 'abcd'를 1번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData2, result_Data)); // > false
		System.out.println();

		System.out.println(" # 'abcc'와 'abcd'를 4번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData2, result_3passedData)); // > false
		System.out.println();

		System.out.println();
		System.out.println();
	}

	private static void performanceTest() throws Exception {

		int COUNT = 1000;
		System.out.println(" TEST COUNT :: " + COUNT);

		System.out.println(" # 'abcd'를 IterateSaltHash 합니다.");
		long startDate = System.currentTimeMillis();
		for (int i = 0; i < COUNT; i++) {
			result_Data = SDBCrypto.digestIterateSaltHash(originalData1);
		}
		long endDate = System.currentTimeMillis();

		long elasped = endDate - startDate;

		System.out.println("SDBCrypto.digestIterateSaltHash(originalData1); :: " + elasped / 1000.0);

		System.out.println("waiting...");
		Thread.sleep(2000);

		System.out.println(" # 'abcd'와 'abcd'를 IterateSaltHash한 값을 검증 테스트합니다.");
		long startDate2 = System.currentTimeMillis();
		for (int i = 0; i < COUNT; i++) {
			SDBCrypto.checkIterateSaltHash(originalData1, result_Data); // > true
		}
		long endDate2 = System.currentTimeMillis();

		long elasped2 = endDate2 - startDate2;

		System.out.println("SDBCrypto.checkIterateSaltHash(originalData1, result_Data); :: " + elasped2 / 1000.0);
	}


	/**
	 * [Key Derivation Function Hash Test2]
	 * 1. digestIterateSaltHash4Client의 사용 샘플 코드.
	 * 2. digestIterateSaltHash4Server의 사용 샘플 코드.
	 **/
	public static void iterateSaltHashClientToServerTestMain() throws Exception {

		digestIterateSaltHash4ClientTest();


		digestIterateSaltHash4ServerTest();


		checkIterateSaltHash4CtoSTest();
	}

	private static void digestIterateSaltHash4ClientTest() throws Exception {


		System.out.println("[digestIterateSaltHash4Client TEST 시작]");
		System.out.println(" > 같은 값을 digestIterateSaltHash4Client 했을 때, 다른 값이 나오는지 확인합니다.");
		System.out.println();


		System.out.println(" # 'abcd'를 1번 digestIterateSaltHash4Client 합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Client(originalData1, "UTF-8");
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println(" # 'abcd'를 1번 digestIterateSaltHash4Client 합니다.");
		result_Data2 = SDBCrypto.digestIterateSaltHash4Client("가나");
		System.out.println(" - result_Data2 :: " + result_Data2);
		System.out.println();
//
//		System.out.println(" # 'abcd'를 1번 digestIterateSaltHash4Client 합니다.");
//		result_Data = SDBCrypto.digestIterateSaltHash4Client(originalData1);
//		System.out.println(" - result_Data :: " + result_Data);
//		System.out.println();


		System.out.println();
		System.out.println();
	}

	private static void digestIterateSaltHash4ServerTest() throws Exception {


		System.out.println("[digestIterateSaltHash4Server TEST 시작]");
		System.out.println(" > digestIterateSaltHash4Client의 결과에서, 원문을 찾아 digestIterateSaltHash를 진행합니다.");
		System.out.println();


		System.out.println(" # 'abcd'를 digestIterateSaltHash4Client한 결과에서, 원문을 찾아 digestIterateSaltHash를 진행합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Server(result_Data);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println(" # 위 결과 값으로 다시 digestIterateSaltHash를 진행합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Server(result_Data);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println(" # 위 결과 값으로 다시 digestIterateSaltHash를 진행합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Server(result_Data);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println(" # 위 결과 값으로 다시 digestIterateSaltHash를 진행합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Server(result_Data);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println(" # 위 결과 값으로 다시 digestIterateSaltHash를 진행합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Server(result_Data);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println(" # 위 결과 값으로 다시 digestIterateSaltHash를 진행합니다.");
		result_Data = SDBCrypto.digestIterateSaltHash4Server(result_Data);
		System.out.println(" - result_Data :: " + result_Data);
		System.out.println();

		System.out.println();
		System.out.println();
	}
//NjEsMjQ4LDgyLDg0LDc5LDEwNSwyMDIsMTUsMjA2LDIwNSwyMDQsMjAzLDMsMTM5LDI0OCwyNTEsNDcsMzUsMTc0LDE2OA==
	private static void checkIterateSaltHash4CtoSTest() throws Exception {

		System.out.println("[checkIterateSaltHash4CtoSTest TEST 시작]");
		System.out.println(" > IterateSaltHash된 값 B, B와 같은 값인지 검증하려는 A, A와 B를 검증하는 테스트입니다.");
		System.out.println();

		System.out.println(" # 'abcd'와 'abcd'를 1번 IterateSaltHash한 값을 테스트합니다.");
		System.out.println(SDBCrypto.checkIterateSaltHash(originalData1, result_Data)); // > true
		System.out.println();

//		System.out.println(" # 'abcd'와 'abcd'를 1번 IterateSaltHash한 값을 테스트합니다.");
//		System.out.println(SDBCrypto.checkIterateSaltHash(originalData1, "NjEsMjQ4LDgyLDg0LDc5LDEwNSwyMDIsMTUsMjA2LDIwNSwyMDQsMjAzLDMsMTM5LDI0OCwyNTEsNDcsMzUsMTc0LDE2OA==")); // > true
//		System.out.println();

		System.out.println();
		System.out.println();
	}
}
