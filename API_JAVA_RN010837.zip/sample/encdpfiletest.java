import com.ksign.securedb.api.SDBCrypto;

public class encdpfiletest {

        public static void main(String[] args) {
                encdpfiletest test = new encdpfiletest();
                test.doTest();
        }

        private void doTest() {
                SDBCrypto crypto = new SDBCrypto();
                boolean res = false;
                try {
                        crypto = SDBCrypto.getInstanceDomain("ksign", "192.168.17.128", 9003);

                        //res = crypto.encryptDPFile("test/test.txt", "test/test_enc.txt", "test/backup/", "dbsec.tb_key.aria256", true, 3);
                        //System.out.println(res);

                        res = crypto.decryptFile("test/test_enc.txt", "test/dec/test_enc.txt", "dbsec.tb_key.aria256", 0, true);
                        System.out.println(res);


                        res = SDBCrypto.checkEncFile("test/test_enc.txt");
                        if(res) {
                                System.out.println("result : Encrypted.");
                        } else {
                                System.out.println("result : Not encrypted.");
                        }

                } catch (Exception e) {
                        e.printStackTrace();
                }
        }

}